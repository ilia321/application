package com.example.myapplication.fragments

import androidx.fragment.app.Fragment
import com.example.myapplication.R

class FourthFragment: Fragment(R.layout.fourth_fragment) {

}